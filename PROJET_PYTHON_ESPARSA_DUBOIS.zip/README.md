**PROJET PYTHON 2019 - ISEN LILLE**

ESPARSA Noé  -  DUBOIS Thomas

**Sujet** : Rogue Like Game

**Titre** : Area 51 RPG

**Instalation** : nécessite python 3.7 uniquement 

**Lancement** : Il suffit de compiler main.py qui instancie gameArchitecture qui va se charger de gérer tout le jeu.

**Commande** : Au cours du jeu le joueur n'a besoin que d'appuer sur les touches 1, 2 ou 3 ainsi que ENTREE.
