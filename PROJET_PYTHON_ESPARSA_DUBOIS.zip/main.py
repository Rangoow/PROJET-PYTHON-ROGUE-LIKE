from GameArchitecture import *

#Instancing the game and launch it
RogueLike = gameArchitecture()
RogueLike.startGame()
