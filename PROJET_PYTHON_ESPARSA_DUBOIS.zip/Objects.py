class Objects:
    def __init__(self):
        pass