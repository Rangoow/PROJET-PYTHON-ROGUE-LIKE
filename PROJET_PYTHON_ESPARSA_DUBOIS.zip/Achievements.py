#LIST OF POSSIBLE ACHIEVEMENTS

achivements1 = ["Le faible" ,"Achete une potion de vie ","Obtain"]
achivements2 = [("Le consomateur :","Utilise 3 potions  ","Obtain")]
achivements3 = [("L'aventurier","Tue 5 mobs ","Obtain")]
achivements4 = [("Le témérraire","Tue 15 mobs ","Obtain")]
achivements5 = [("Bonne étoile ","Finis le jeu  ","Obtain")]
achivements6 = [("Nooby","Meurt ","Obtain")]
achivements7 = ["La bonne note","Tu as mis 15/20 à Noé et Thomas","Obtain"]